# My Code
def solution(arr):
    return sum(arr)/len(arr)

list = [1,2,3,4]
print("평균값 : {}".format(solution(list)))
print(solution([5,5]))