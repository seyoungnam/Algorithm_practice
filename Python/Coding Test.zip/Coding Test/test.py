def test():
    flag = 3
    print(len(str(flag)))

if __name__ == '__main__':
    test()